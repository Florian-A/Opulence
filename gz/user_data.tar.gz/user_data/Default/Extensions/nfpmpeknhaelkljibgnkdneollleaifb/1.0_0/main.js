var fakeNavigatorProperties =  '(' + function() {

    Object.defineProperties(navigator, {

        platform: {
            value: 'PLATFORM',
            configurable: false,
            enumerable: true,
            writable: false
        },
        language: {
            value: 'LANGUAGE',
            configurable: false,
            enumerable: true,
            writable: false
        },
        maxTouchPoints: {
            value: 'TOUCHPOINTS',
            configurable: false,
            enumerable: true,
            writable: false
        },
        doNotTrack: {
            value: 'DONOTTRACK',
            configurable: false,
            enumerable: true,
            writable: false
        },
        cpuClass: {
            value: 'CPUCLASS',
            configurable: false,
            enumerable: true,
            writable: false
        },
    });
    Object.defineProperties(screen, {

        height: {
            value: 'HEIGHT',
            configurable: false,
            enumerable: true,
            writable: false
        },
        width: {
            value: 'WIDTH',
            configurable: false,
            enumerable: true,
            writable: false
        },
        availHeight: {
            value: 'HEIGHT',
            configurable: false,
            enumerable: true,
            writable: false
        },
        availWidth: {
            value: 'WIDTH',
            configurable: false,
            enumerable: true,
            writable: false
        },
        colorDepth: {
            value: 'COLORDEPTH',
            configurable: false,
            enumerable: true,
            writable: false
        },
    });
} + ')();';

var documentScript = document.createElement('script');
documentScript.textContent = fakeNavigatorProperties;
document.documentElement.appendChild(documentScript);
documentScript.remove();
